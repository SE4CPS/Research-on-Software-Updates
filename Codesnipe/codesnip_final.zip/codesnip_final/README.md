# Codesnip

A CLI tool to analyze GitHub PRs, run code quality checks, and generate AI-powered release notes.